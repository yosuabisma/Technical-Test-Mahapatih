<template>
  <div id="saved">
    <div id="req-saved">
      <center>
        <div id="chart">
          <apexcharts type=radialBar height=400 :options="chartOptions" :series="seriesReq" />
        </div>
        <div id="desc-req">
          <font style="color:#849FB4;font-size:20px;font-family:'Montserrat-Medium'">Request Saved</font><br/>
          <font style="color:#C2D7E8;font-size:12px;font-family:'Montserrat'">147k request cached from 267k total</font>
        </div>
      </center>
    </div>
    <div id="gb-saved">
      <center>

        <div id="chart">
          <apexcharts type=radialBar height=400 :options="chartOptions" :series="seriesGB" />
        </div>
        <div id="desc-req">
          <font style="color:#849FB4;font-size:20px;font-family:'Montserrat-Medium'">GB's Saved</font><br/>
          <font style="color:#C2D7E8;font-size:12px;font-family:'Montserrat'">9.80 GB saved from 10.41 GB total</font>
        </div>
      </center>
    </div>
  </div>
</template>
<script>
import VueApexCharts from 'vue-apexcharts';
export default {
  components: {
    'apexcharts': VueApexCharts,
  },
  data() {
    return {
      seriesReq: [20],
      seriesGB: [40],
        chartOptions: {
          plotOptions: {
            radialBar: {
              startAngle: -90,
              endAngle: 90,
              track: {
                background: "#0D1539",
                stroke: {
                  show: true,
                  colors: '#ffffff',
                  width: 20,
                },
                shadow: {
                  enabled: true,
                  top: 2,
                  left: 0,
                  color: '#999',
                  opacity: 1,
                  blur: 2
                }
              },
              dataLabels: {
                name: {
                  show: false,
                },
                value: {
                  offsetY: 15,
                  fontSize: '26px',
                  color:'#FFFFFF',
                  fontFamily:'Montserrat',
                }
              }
            }
          },
          fill: {
            colors:['#5B9CFF'],
          },
        }
    };
  },
};

</script>
<style scoped>
#saved{
  width:366.83px;
  height: 685px;
  border-radius: 4px;
  background-color: #0D1539;
  padding-right: 6px;
  padding-left: 4.51px;
  padding-top: 5.4px;
  margin-top: 15.25px;
}

#desc-req{
  margin-top: -150px;
}
</style>
