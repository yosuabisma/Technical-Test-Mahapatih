<template>
  <div id="cache-coverage">
    <div id="cache-title">
      Cache Coverage
    </div>
    <div id="chart-donut">
      <apexcharts type="donut" width=320 :options="chartOptions" :series="series" />
    </div>
    <div id="percentage">
      25%
    </div>
  </div>
</template>
<script>
  import VueApexCharts from 'vue-apexcharts';
  export default {
    components: {
      'apexcharts': VueApexCharts,
    },
    data() {
      return {
        series: [25, 25, 25, 25],

        chartOptions: {
          labels: ['Hits','Expired','Misses','Not Cached'],
          colors: ['#6783FF', '#4BD963', '#FF5E39', '#CCCCCC'],

          dataLabels: {
            enabled: false
          },
          fill: {
            colors: ['#6783FF', '#4BD963', '#FF5E39', '#CCCCCC'],

          },
          stroke: {
            show: true, curve: 'smooth',
            lineCap: 'butt',
            colors: '#0D1539',
            width: 0,
            dashArray: 0,
          },

          tooltip: {
            enabled: false,
          },
          legend: {
              show: true,
              position: 'right',
              horizontalAlign: 'center',
              labels: {
                  colors: ["#849FB4"],
                  useSeriesColors: false,
                  fontFamily: 'Montserrat',
                  fontSize: '12px',
                  lineHeight: '15px',
              },
              itemMargin: {
                 horizontal: '15px',
                 vertical: '22px',
             },
             onItemClick: {
                 toggleDataSeries: true
             },
             onItemHover: {
                 highlightDataSeries: true
             },

          },


          responsive: [{
            breakpoint: 180,
            options: {
              chart: {
              },

            }
          }]
        }

      };
    },
  };
</script>
<style scoped>
  #cache-title{
    font-size: 20px;
    line-height: 24px;
    color: #849FB4;
    background-color: #070C24;
    width: 427px;
    height: 47.21px;
    padding-top: 20px;
    padding-left: 11px;
  }
  #cache-coverage{
    margin-top: -79.53px;
    width:437.64px;
    height: 306.22px;
    border-radius: 8px;
    background-color: #0D1539;
    padding-right: 6px;
    padding-left: 4.51px;
    padding-top: 5.4px;
    margin-top: 29.53px;
  }
  #chart-donut{
    padding-left: 40px;
    padding-top: 20px;
  }
  #percentage{
    color:#ffffff;
    font-weight: bold;
    font-size: 20px;
    margin-top: -238px;
    margin-left: 134px;
  }

</style>
