<template>
  <div id="left-menu">
    <div class="menu-box active">
      <img src="./../assets/Group 174.png">
      <router-view/>
    </div>
    <div class="menu-box">
      <img src="./../assets/Path 188.png">
      <router-view/>
    </div>
    <div class="menu-box">
      <img src="./../assets/history.png">
      <router-view/>
    </div>
    <div class="menu-box">
      <img src="./../assets/verification-window-button.png">
      <router-view/>
    </div>
    <div class="menu-box">
      <img src="./../assets/locked-padlock (1).png">
      <router-view/>
    </div>
  </div>
</template>
<script></script>
<style scoped>
#left-menu{
  margin-left: 113.56px;
  margin-top: -699.53px;
}
img{
  width: 27.79px;
  height: 27.79px;
  padding-top: 13.42px;
  padding-bottom:16.58px;
  padding-right: 25.09px;
  padding-left: 23.39px;
}
.menu-box{
  width: 76.28px;
  height: 57.79px;
  margin-bottom: 26.50px;
  cursor:pointer;
}
.menu-box:hover{
  background-color: rgba(132, 159, 180, 0.03);
}
.active{
  background-color: rgba(132, 159, 180, 0.03);
}

</style>
