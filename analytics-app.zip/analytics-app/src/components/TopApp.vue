<template>
  <div id="top-app">
    <div id="top-app-title">
      Top Application
    </div>
    <div id="apps-list">
      <table>
        <tr v-for="app in apps">
          <td class="app-cell">{{app.name}}</td>
          <td class="app-cell" id="app-bar-col">
            <!-- {{app.value}} -->
            <div class="app-bar" v-bind:style="{height:'14px',width:(app.value*148)+'px'}"></div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      apps:[
        {name:'Application-1', value:0.2},
        {name:'Application-2', value:0.4},
        {name:'Application-3', value:0.6},
        {name:'Application-4', value:0.8},
        {name:'Application-5', value:1.0}
      ]
    }
  }
}
</script>
<style scoped>
#top-app-title{
  font-size: 20px;
  line-height: 24px;
  color: #849FB4;
  background-color: #070C24;
  width: 319px;
  height: 47.21px;
  padding-top: 20px;
  padding-left: 11px;
}
#top-app{
  width:330.83px;
  height: 335px;
  border-radius: 4px;
  background-color: #0D1539;
  padding-right: 6px;
  padding-left: 4.51px;
  padding-top: 5.4px;
  margin-top: 15.25px;
}
#apps-list{
  margin-top: 44.88px;
  margin-left: 22.65px;
  color: #849FB4;
  font-weight: semibold;
  font-size: 12px;
  line-height: 15px;
}
#app-row{
  padding-bottom: 31px;
}
#app-bar-col{
  padding-left: 40px;
}
.app-cell{
  padding-bottom: 25px;
}
.app-bar{
  background-image: linear-gradient(-90deg, #5B9CFF, #6783FF);
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}

</style>
