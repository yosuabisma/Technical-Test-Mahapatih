<template>
  <div id="contents">
    <table>
      <tr>
        <td id="left-content"><!--Left Menu--><LeftMenu/></td>
        <td >
          <!--Content Box-->
          <table id="right-content">
            <tr>
              <table>
                <tr>
                  <td id="malware-col"><!--Malware Download Sessions--><MalwareDownload/></td>
                  <td id="cache-col"><!--Cache Coverage--><CacheCoverage/></td>
                </tr>
              </table>
            </tr>
            <tr >
              <td colspan="2" id="alerts-section"><!-- Alerts Table--><Alerts/></td>
            </tr>
            <tr>
              <table>
                <tr>
                  <td rowspan="2" id="saved-section"><!-- Saved--><Saved/></td>
                  <td>
                    <table id="table-countries-app-mlw">
                      <tr>
                        <td colspan="2" id="countries-section"><!--Countries--><Countries/></td>
                      </tr>
                      <tr>
                        <td id="app-section"><!--TopApplication--><TopApp/></td>
                        <td id="mlw-section"><!--TopMalware--><TopMlw/></td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </tr>
          </table>
        </td>
      </tr>
    </table>

  </div>
</template>
<script>
  import LeftMenu from './LeftMenu.vue';
  import CacheCoverage from './CacheCoverage.vue';
  import MalwareDownload from './MalwareDownload.vue';
  import Alerts from './Alerts.vue';
  import Saved from './Saved.vue';
  import Countries from './Countries.vue';
  import TopApp from './TopApp.vue';
  import TopMlw from './TopMlw.vue';
  export default {
    components: {
      'LeftMenu':LeftMenu,
      'CacheCoverage':CacheCoverage,
      'MalwareDownload':MalwareDownload,
      'Alerts':Alerts,
      'Saved':Saved,
      'Countries':Countries,
      'TopApp':TopApp,
      'TopMlw':TopMlw,
    },
    data() {
      return {

      }
    }
  }
</script>
<style scoped>
  #right-content{
    padding-bottom: 77.86px;
  }
  #malware-col{
    padding-right: 14px;
    padding-left: 12.21px;
  }
  #alerts-section{
    padding-left: 12.21px;
  }
  #saved-section{
    padding-left: 12.21px;
  }
  #countries-section{
    padding-left: 15.17px;
  }
  #app-section{
    padding-left: 15.17px;
  }
  #mlw-section{
    padding-left: 15.17px;
  }
  #table-countries-app-mlw{
    top:0;
  }
</style>
