<template>
<div>

  <div id="app-user">
    <table>
      <tr>
        <td>
          <img src="./../assets/profilepic.png" id="profpic">
          <router-view/>
        </td>
        <td>
          <div id="username">
            <table>
              <tr>
                <td><font>{{username}}</font></td><td><div id="triangle-down"></div></td>
              </tr>
            </table>
          </div>
        </td>
        <td>
          <div id="datetime">
            <font id="date">{{date}}</font><br/>
            <font id="clock">{{clock}}</font>
          </div>
        </td>
      </tr>
    </table>
  </div>
</div>
</template>
<script>
  export default {
    data() {
      return {
        username: 'Ari Marpaung',
        clock: '2.45 AM',
        date:'17-02-2018',
      }
    }
  }
</script>
<style scoped>
  #profpic{
    height: 56.31px;
    width:57.31px;
    border-radius: 50%;
    border: 3px #ffffff solid;
    margin-left: -28.655px;
  }
  #app-user{
    width:356.14px;
    height: 77px;
    float:right;
    background-image: linear-gradient(89deg, #6783FF, #4bc2ff);
    position:left;
    color:#ffffff;
  }
  #username{
    font-size: 13px;
    line-height: 16px;
    margin-left: 15.47px;
    margin-top: 29.71px;
    margin-bottom: 31.29px;
  }
  #triangle-down{
    margin-left: 8.2px;
    width: 0;
    height: 0;
    border-left: 7.97px solid transparent;
    border-right: 7.97px solid transparent;
    border-top: 7.97px solid #ffffff;
  }
  #datetime{
    margin-left: 32.73px;
    margin-top: 17.29px;
    margin-bottom: 19.71px;
  }
  #date{
    font-weight: semibold;
    font-size: 12px;
    line-height: 15px;
  }
  #clock{
    font-weight: bold;
    font-size: 20px;
    line-height: 24px;
  }
</style>
