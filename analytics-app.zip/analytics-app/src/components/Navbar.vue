<template>
  <div class="navbar">
    <table>
      <tr>
        <td id="app-title">
            <div id="dash-title">
              ANALYTICS <span id="dash-font">DASHBOARD</span>
            </div>
        </td>
        <td id="user-div">
          <UserLogin/>
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
  import UserLogin from './UserLogin.vue';
  export default {
    components: {
      'UserLogin':UserLogin,
    },
    data() {
      return {

      }
    }
  }
</script>
<style scoped>
  table{
    width:100%;
  }
  #app-title{
    width:1009.86px;
    color:#849fb4;
    font-size: 20px;
  }
  #dash-title{
    margin-left: 113px;
    margin-top: 27px;
    line-height: 24px;
  }
  #dash-font{
    color: #52b4ff;
  }

</style>
