<template>
  <div id="top-mlw">
    <div id="top-mlw-title">
      Top Malware
    </div>
    <div id="mlws-list">
      <table>
        <tr v-for="mlw in mlws">
          <td class="mlw-cell">{{mlw.name}}</td>
          <td class="mlw-cell" id="mlw-bar-col">
            <!-- {{app.value}} -->
            <div class="mlw-bar" v-bind:style="{height:'14px',width:(mlw.value*148)+'px'}"></div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      mlws:[
        {name:'Malware-1', value:1.0},
        {name:'Malware-2', value:0.8},
        {name:'Malware-3', value:0.6},
        {name:'Malware-4', value:0.4},
        {name:'Malware-5', value:0.2}
      ]
    }
  }
}
</script>
<style scoped>
#top-mlw-title{
  font-size: 20px;
  line-height: 24px;
  color: #849FB4;
  background-color: #070C24;
  width: 319px;
  height: 47.21px;
  padding-top: 20px;
  padding-left: 11px;
}
#top-mlw{
  width:330.83px;
  height: 335px;
  border-radius: 4px;
  background-color: #0D1539;
  padding-right: 6px;
  padding-left: 4.51px;
  padding-top: 5.4px;
  margin-top: 15.25px;
}
#mlws-list{
  margin-top: 44.88px;
  margin-left: 22.65px;
  color: #849FB4;
  font-weight: semibold;
  font-size: 12px;
  line-height: 15px;
}
#mlw-row{
  padding-bottom: 31px;
}
#mlw-bar-col{
  padding-left: 40px;
}
.mlw-cell{
  padding-bottom: 25px;
}
.mlw-bar{
  background-image: linear-gradient(-90deg, #5B9CFF, #6783FF);
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
</style>
