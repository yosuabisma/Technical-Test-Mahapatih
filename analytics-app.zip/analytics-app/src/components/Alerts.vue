<template>
  <div id="alerts">
    <div id="alerts-title">
      Alerts
    </div>
    <table style="width:100%;">
      <thead>
        <tr id="header-table"><th>Alert</th><th>Severity</th><th>Source IPv4</th><th>Target IPv4</th><th>Device</th><th>Timestamp</th></tr>
      </thead>
      <tbody>
        <tr v-for="row in rows" class="row-table">
          <td>{{row.alert}}</td>
          <td>{{row.severity}}</td>
          <td>
            <div v-if="row.srcIP!=='none'">{{row.srcIP}}</div>
            <div v-if="row.srcIP==='none'">
              <div class="noneIP"></div>
            </div>
          </td>
          <td>
            <div v-if="row.tarIP!=='none'">{{row.tarIP}}</div>
            <div v-if="row.tarIP==='none'">
              <div class="noneIP"></div>
            </div>
          </td>
          <td>{{row.device}}</td>
          <td>{{row.timestamp}}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
  export default {
    data(){
      return{
        rows:[
          {alert:'THREAT_INTEL',severity:'INTEL',srcIP:'10.128.35.6',tarIP:'none',device:'IA',timestamp:'2017-05-11T11:59:02.652544+0000'},
          {alert:'THREAT_INTEL',severity:'INTEL',srcIP:'none',tarIP:'10.128.35.6',device:'IA',timestamp:'2017-05-11T11:59:02.652544+0000'},
          {alert:'THREAT_INTEL',severity:'INTEL',srcIP:'10.128.35.6',tarIP:'none',device:'IA',timestamp:'2017-05-11T11:59:02.652544+0000'},
        ]
      };
    },
  };
</script>
<style scoped>
table{
  border:none;
  border-collapse: collapse;
}
#alerts-title{
  font-size: 20px;
  line-height: 24px;
  color: #849FB4;
  background-color: #070C24;
  width: 1047.95px;
  height: 47.21px;
  padding-top: 20px;
  padding-left: 11px;
}
#alerts{
  width:1059.08px;
  height: 254px;
  border-radius: 4px;
  background-color: #0D1539;
  padding-right: 6px;
  padding-left: 4.51px;
  padding-top: 5.4px;
  margin-top: 15.25px;
}
#header-table{
  height: 42px;
  background-color: #070C24;
  width: 1047.95px;
  font-weight: semibold;
  color: #849FB4;
  font-size: 12px;
  line-height: 15px;
}
th,td{
  text-align: left;
  padding-left: 17.55px;
}
.row-table td{
  padding-top: 13px;
  padding-bottom: 13px;
  border-bottom: 1px rgba(65, 85, 142, 0.19) solid;
  color:#FFFFFF;
  font-size: 12px;
  line-height: 15px;
}
.noneIP{
  width:157.04px;
  height:15.99px;
  background-image: linear-gradient(-90deg, #5B9CFF, #6783FF);
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
</style>
