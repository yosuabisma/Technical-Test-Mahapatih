<template>
  <div id="tab-menu">
    <ul>
      <li><a class="active">Tab Menu Utama</a></li>
      <li><a>Tab Menu 2</a></li>
      <li><a>Tab Menu 2</a></li>
      <li><a>Tab Menu 2</a></li>
      <li><a>Tab Menu 2</a></li>
    </ul>
    <hr>
  </div>
</template>
<script>
</script>
<style scoped>
  #tab-menu{
    padding: 0;
  }
  hr{
    border: 1px #BEBEBE solid;
    width: 1060.8px;
    opacity: 0.2;
    margin-left: 201.7px;
  }
  ul{
    list-style-type: none;
    overflow: hidden;
    padding: 0;
    margin-top: 46.9px;
    margin-left: 207.89px;
    margin-bottom: 20.98px
  }
  li {
    float: left;
    margin: 0;
  }
  li a {
    display: block;
    color: #849FB4;
    text-decoration: none;
    font-size: 14px;
    line-height: 18px;
    margin-right: 66px;
  }
  .active{
    color: #08A4BC;
    font-weight: semibold;
  }
  li a:hover {
    color: #08A4BC;
    cursor: pointer;
  }



</style>
