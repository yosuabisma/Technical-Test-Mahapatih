<template>
  <div id="dashboard">
    <Navbar/>
    <DocotelData/>
    <TabMenu/>
    <DashboardContent/>
  </div>
</template>
<script>
  import Navbar from './Navbar.vue';
  import DocotelData from './DocotelData.vue';
  import TabMenu from './TabMenu.vue';
  import DashboardContent from './DashboardContent.vue';
  export default {
    components: {
      'Navbar':Navbar,
      'DocotelData':DocotelData,
      'TabMenu':TabMenu,
      'DashboardContent':DashboardContent,
    },
    data() {
      return {

      }
    }
  }
</script>
<style scoped>
</style>
