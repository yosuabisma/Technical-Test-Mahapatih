<template>
  <div id="docotel">
    <table>
      <tr>
        <td>
          <img src="./../assets/logo-docotel.png" id="logo-docotel">
          <router-view/>
        </td>
        <td>
          <h2 class="indicator">Last</h2>
          <h2 class="indicator-data">{{last}}</h2>
        </td>
        <td>
          <h2 class="indicator">High</h2>
          <h2 class="indicator-data">{{high}}</h2>
        </td>
        <td>
          <h2 class="indicator">Low</h2>
          <h2 class="indicator-data">{{low}}</h2>
        </td>
        <td>
          <h2 class="indicator">Alert</h2>
          <h2 class="indicator-data">{{alert}}</h2>
        </td>
        <td>
          <h2 class="indicator">Malware</h2>
          <h2 class="indicator-data">{{malware}}</h2>
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  data() {
    return {
      last: 2.4556,
      high: 3.4556,
      low: 1.4556,
      alert: 3.4556,
      malware: 3.4556,
    }
  }
}
</script>
<style scoped>
  #logo-docotel{
    width:111px;
    height: 68px;
    margin-left: 113.73px;
    margin-right: 73.76px;
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1);
  }
  #docotel{
    width:100%;
    height:70.27px;
    background-color: #0D1539;
    opacity: 1.0;
    overflow: hidden;
    text-align: left;
  }
  .indicator{
    margin-right: 127.67px;
    margin-top: 12px;
    color: #849FB4;
    font-size: 13px;
    line-height: 16px;
    font-family: 'Montserrat-Medium';
  }
  .indicator-data{
    margin-right: 127.67px;
    margin-top: -4px;
    color: #52B4FF;
    font-size: 20px;
    line-height: 24px;
    font-weight: bold;
  }
</style>
