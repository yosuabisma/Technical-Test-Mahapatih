<template>
  <div id="countries">
    <div id="countries-title">
      Source Countries
    </div>
    <div id="countries-content">
      <div id="map-section">
        <table>
          <tr>
            <td>
              <img src="./../assets/map.png" id="map">
              <router-view/>
            </td>
            <td id="map-legend">
              <div id="map-legend-desc" v-for="map in maps">
                <div class="country-legend">
                  <table>
                    <tr>
                      <td><div class="ring-legend" v-bind:style="{border:'3px solid '+map.hexcolor}"></div></td><td>{{map.country}}</td>
                    </tr>
                  </table>
                </div>
              </div>
            </td>
          </tr>
        </table>
      </div>
      <div id="map-marker">

        <div class="marker-point" v-for="map in maps">
          <!--marker content-->
          <div class="bounce" v-bind:id="map.id">
            <div class="marker" v-bind:style="{borderColor:map.hexcolor, border:'6px solid '+map.hexcolor,}" ></div>
            <div class="marker2" v-bind:style="{borderTop:'10px solid '+map.hexcolor}"></div>
            <div class="pulse"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      maps:[
        {country:'Indonesia', hexcolor:'#FFA177', id:'idn'},
        {country:'United States', hexcolor:'#A3A1FB', id:'usa'},
        {country:'South America', hexcolor:'#5EE2A0', id:'sam'},
        {country:'Russia', hexcolor:'#FF7CC3', id:'rus'},
        {country:'Spain', hexcolor:'#54D8FF', id:'esp'}
      ]
    }
  }
}
</script>
<style scoped>
#countries-title{
  font-size: 20px;
  line-height: 24px;
  color: #849FB4;
  background-color: #070C24;
  width: 665px;
  height: 47.21px;
  padding-top: 20px;
  padding-left: 11px;
}
#countries{
  width:676.83px;
  height: 335px;
  border-radius: 4px;
  background-color: #0D1539;
  padding-right: 6px;
  padding-left: 4.51px;
  padding-top: 5.4px;
  margin-top: 15.25px;
}
#countries-content{
  padding-top: 44.06px;
  padding-left: 22.49px;
}
#map-legend{
  padding-left: 87px;
}
#map-legend-desc{
  color:#849FB4;
  font-size: 12px;
  line-height: 15px;
  font-weight: semibold;
}
.country-legend{
  margin-bottom: 22.87px;
}
.ring-legend{
  width: 8px;
  height: 8px;
  border-radius: 50%;
  border: 3px solid #fff;
  margin-right: 14.98px;
}
#map-section{
  position: relative;
  z-index: 0;
}
#map{
  width: 385.17px;
  height: 190.59px;
}
#map-marker{
  position: relative;
  z-index: 1;
}
.marker {
  border-radius: 50%;
  border: 6px solid #fff;
  width: 4px;
  height: 4px;
}
.marker2{
  width: 2px;
  height: 2px;
  margin-top: -4px;
  margin-left: 1px;
  left: -4px;
  border: 6px solid transparent;
  border-top: 10px solid #fff;
}
.bounce{
  animation-name: bounce;
  animation-fill-mode: both;
  animation-duration: 1s;
}

@keyframes bounce {
  0% {
    opacity: 0;
    transform: translateY(-100px);
  }

  60% {
    opacity: 1;
    transform: translateY(30px);
  }

  80% {
    transform: translateY(-10px) ;
  }

  100% {
    transform: translateY(0);
  }
}

.pulse {
  background: #d6d4d4;
  border-radius: 50%;
  height: 14px;
  width: 14px;
  position: absolute;
  /* left: 50%;
  top: 50%; */
  margin: -15px 0px 0px 0px;
  transform: rotateX(55deg);
  z-index: -2;
}
.pulse:after {
  content: "";
  border-radius: 50%;
  height: 40px;
  width: 40px;
  position: absolute;
  margin: -13px 0 0 -13px;
  animation: pulsate 1s ease-out;
  animation-iteration-count: infinite;
  opacity: 0;
  box-shadow: 0 0 1px 2px #00cae9;
  animation-delay: 1.1s;
}

@keyframes pulsate {
  0% {
    transform: scale(0.1, 0.1);
    opacity: 0;
  }

  50% {
    opacity: 1;
  }

  100% {
    transform: scale(1.2, 1.2);
    opacity: 0;
  }
}

#idn{
  margin-left:300px;
  margin-top:-95px;
}
#usa{
  margin-left:60px;
  margin-top:-80px;
}
#sam{
  margin-left:110px;
  margin-top:20px;
}
#rus{
  margin-left:300px;
  margin-top:-130px;
}
#esp{
  margin-left:170px;
  margin-top:15px;
}
</style>
